package B4_ThreadInteruption;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class InterrupExample {
    public static void main(String[] args) throws InterruptedException {
        ExecutorService executor = Executors.newSingleThreadExecutor();

        Runnable task = () -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    System.out.println("Worker is running...");
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    System.out.println("Worker thread interrupted!");
                    break; // Không cần gọi lại interrupt(), vì Future.cancel(true) sẽ xử lý
                }
            }
            System.out.println("Worker stopped.");
        };

        Future<?> future = executor.submit(task);
        Thread.sleep(3000);
        future.cancel(true); // Dừng luồng
        executor.shutdown();
    }
}
