package inSoChanLe;

public class Main {
    public static void main(String[] args) {
        PrintNumber printNumber = new PrintNumber();

        Thread oddThread = new Thread(printNumber::inSoLe);
        Thread evenThread = new Thread(printNumber::inSoChan);

        oddThread.start();
        evenThread.start();
    }
}
