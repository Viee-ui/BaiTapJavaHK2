package inSoChanLe;

class PrintNumber {
    private int number = 1;
    private final int MAX = 10;

    public synchronized void inSoLe() {
        while (number <= MAX) {
            while (number % 2 == 0) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (number <= MAX) {
                System.out.println("Lẻ: " + number);
                number++;
                notify();
            }
        }
    }

    public synchronized void inSoChan() {
        while (number <= MAX) {
            while (number % 2 != 0) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (number <= MAX) {
                System.out.println("Chẵn: " + number);
                number++;
                notify();
            }
        }
    }
}
