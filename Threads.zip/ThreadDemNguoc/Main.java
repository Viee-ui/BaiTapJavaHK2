package ThreadDemNguoc;

public class Main {
    public static void main(String[] args) {
        CountDownThread countDownThread = new CountDownThread();
        Thread thread = new Thread(countDownThread);
        thread.start();
    }
}
