package B5_MemoryVisibilityIssue;

class VisibilityExample {
    private static volatile boolean flag = false; // Dùng volatile để đảm bảo visibility

    public static void main(String[] args) {
        new Thread(() -> {
            while (!flag) {} // Vòng lặp này giờ sẽ nhận ra sự thay đổi của flag ngay lập tức
            System.out.println("Flag changed!");
        }).start();

        try {
            Thread.sleep(2000); // Đợi 2 giây trước khi thay đổi flag
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        flag = true; // Worker thread sẽ nhìn thấy sự thay đổi ngay lập tức
    }
}

