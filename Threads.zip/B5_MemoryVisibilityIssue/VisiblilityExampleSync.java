package B5_MemoryVisibilityIssue;

// Dùng synchronized

class VisibilityExampleSync {
    private static boolean flag = false;

    public static synchronized boolean getFlag() {
        return flag;
    }

    public static synchronized void setFlag(boolean value) {
        flag = value;
    }

    public static void main(String[] args) {
        new Thread(() -> {
            while (!getFlag()) {} // Đọc flag thông qua synchronized method
            System.out.println("Flag changed!");
        }).start();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        setFlag(true); // Ghi flag thông qua synchronized method
    }
}

