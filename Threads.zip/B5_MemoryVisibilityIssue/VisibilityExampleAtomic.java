package B5_MemoryVisibilityIssue;

// Dùng AtomicBoolean

import java.util.concurrent.atomic.AtomicBoolean;

class VisibilityExampleAtomic {
    private static AtomicBoolean flag = new AtomicBoolean(false);

    public static void main(String[] args) {
        new Thread(() -> {
            while (!flag.get()) {} // Đọc giá trị flag an toàn
            System.out.println("Flag changed!");
        }).start();

        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        flag.set(true); // Cập nhật flag an toàn
    }
}

